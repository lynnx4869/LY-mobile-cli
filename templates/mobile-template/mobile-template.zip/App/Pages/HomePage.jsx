import React from 'react';

class HomePage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    componentDidMount() {

    }

    render() {
        return (
            <section>
                This is main page.
            </section>
        );
    }
}

export default HomePage;